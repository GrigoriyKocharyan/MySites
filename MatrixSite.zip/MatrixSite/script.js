let root =  document.documentElement
root.style.setProperty('--screen-w', screen.width);


